define({
	paths: {
		app		: 'http://blog.project.dev',
		cdn		: 'http://blog.project.dev/cdn',
		api		: 'http://127.0.0.1:8080',
		auth	: 'http://127.0.0.1:8081'
	}
});