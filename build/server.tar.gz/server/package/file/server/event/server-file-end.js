module.exports = function(meta) {
	//end the stream
	meta.stream.end(); 
};