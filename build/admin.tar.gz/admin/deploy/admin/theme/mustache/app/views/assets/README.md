This folder contains inline scripts and styles used in each page.

Usually you do this in another other way for example by registering files and snippets during application run
and inserting them in the output at the right spot.

