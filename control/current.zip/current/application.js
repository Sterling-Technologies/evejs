jQuery(function($) {
	var api	= 'http://api.lbc.dev:8082';
	
	require.config({
	    paths: { text: '/scripts/text' },
		config: {
			text: {
				useXhr: function (url, protocol, hostname, port) {
					// allow cross-domain requests
					// remote server allows CORS
					return true;
			  	}
			}
		}
	});
	
	require([
		'text!/template/head.html',
		'text!/template/body.html',
		'text!/template/foot.html',
		'text!/template/menu.html',
		'text!/template/alert.html',
		'text!/template/crumbs.html'], 
		function(head, body, foot, menu, alert, crumbs) {
			var partials = {
				head	: head,
				foot	: foot,
				menu	: menu,
				alert	: alert,
				crumbs	: crumbs };
				
			var data = {
				header		: 'Header 1',
				subheader	: 'Subheader',
				body		: 'Some Body',
				right		: false,
				has_crumbs	: true,
				crumbs: [{
					has_icon: true,
					icon	: 'facebook',
					has_path: true,
					path	: '#',
					label	: 'Item 1'
				}, {
					has_icon: true,
					icon	: 'facebook',
					has_path: true,
					path	: '#',
					label	: 'Item 1'
				}, {
					has_icon: false,
					icon	: 'facebook',
					has_path: false,
					path	: '#',
					label	: 'Item 1'
				}],
				messages: [{
					type	: 'error',
					message	: 'okay',
					icon	: 'ok'
				}, {
					type	: 'success',
					message	: 'okay',
					icon	: 'facebook'
				}],
				menu: [{
					active	: true,
					path	: '#',
					icon	: 'pencil',
					label	: 'Item 1',
					has_children: true,
					children: [{
						active	: true,
						path	: '#',
						icon	: 'pencil',
						label	: 'Item 1',
						has_children: true,
						children: [{
							active	: true,
							path	: '#',
							icon	: 'pencil',
							label	: 'Item 1'
						}, {
							active	: false,
							path	: '#',
							icon	: 'pencil',
							label	: 'Item 2'
						}]
					}, {
						active	: false,
						path	: '#',
						icon	: 'pencil',
						label	: 'Item 1',
						has_children: false,
					}]
				}, {
					active	: false,
					path	: '#',
					icon	: 'pencil',
					label	: 'Item 1',
					has_children: false,
				}]
			};
			
			var html = Mustache.render(body, data, partials);
			
			$(document.body).html(html);
		});
	
	
});